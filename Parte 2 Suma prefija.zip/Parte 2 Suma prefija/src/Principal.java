public class Principal {
    public static void main(String[] args) {

        int x = Integer.parseInt(args[0]);
        System.out.println("Mision: dos numeros del arreglo que sumados nos den X");
        System.out.println("Nuestra X: "+x);
        System.out.print("Arreglo: ");

        int[] A = new int[args.length-1];
        for (int i = 0; i < A.length; i++) {

            A[i] = Integer.parseInt(args[i+1]);
            System.out.print(A[i]+" ' ");

        }//fin for

        int suma = 0;
        boolean comprobador = false;

        for (int i = 0; i <A.length ; i++) {
            for (int j = 0; j <A.length ; j++) {
                if(i == j){
                    continue;
                }

                suma = A[i] + A[j];
                if(suma == x){
                    comprobador = true;
                }

            }//fin for j
        }//fin for i

        System.out.println();

        if(comprobador){
            System.out.println("Cumple con los requisitos? = si");
        }
        else{
            System.out.println("Cumple con los requisitos? = no");
        }


    }//fin main
}//fin class
